Files TP2_v1 adn TP2_v2 are the python files for TP2.
version 1 is a really simple, buggy file that can read the lane via video.
version 2 is a much optimized and better working version than V1
Tp_images is the file for testing images and videos
	!!Test4.mp4 is the best test video if you wish to test the code.